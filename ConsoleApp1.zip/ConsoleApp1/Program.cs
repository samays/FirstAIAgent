using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Configuration;
using OpenAI;
using OpenAI.Chat;
using System.ComponentModel;

// Token'ı User Secrets'tan oku (dotnet user-secrets set "GitHubToken" "token")
var config = new ConfigurationBuilder()
    .AddUserSecrets<Program>()
    .Build();

var githubToken = config["GitHubToken"]
    ?? throw new InvalidOperationException("GitHubToken bulunamadı. Lütfen User Secrets ayarlayın.");

var endpoint = new Uri("https://models.github.ai/inference");
var model = "openai/gpt-4.1-mini";

var openAIClientOptions = new OpenAIClientOptions
{
    Endpoint = endpoint,
};

[Description("Verilen müşteri için bu günkü sipariş sayısını döndür")]
static int GetOrderCountToday(
    [Description("Müşteri adı")] string customerName)
{
    Console.WriteLine("Tool Working...");
    return 12;
}

AIAgent aIAgent = new ChatClient(model, new ApiKeyCredential(githubToken), openAIClientOptions)
    .AsIChatClient()
    .AsAIAgent(
        instructions: "Sen yardımcı bir asistansın, kısa cevaplar ver",
        name: "Test Agent",
        tools: [AIFunctionFactory.Create(GetOrderCountToday)]);

Console.Write("Mesajınız: ");
string msg = Console.ReadLine()!;
var response = await aIAgent.RunAsync(msg);
Console.WriteLine(response);
